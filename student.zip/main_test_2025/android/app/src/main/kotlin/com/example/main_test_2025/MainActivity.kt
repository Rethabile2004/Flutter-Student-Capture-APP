package com.example.main_test_2025

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
