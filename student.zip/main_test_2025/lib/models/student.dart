//
// Coder                    : Rethabile Eric Siase
// Time taken to complete   : 2 hours
// Number of external help  : 0
// Purpose                  : To demonstrate basic navigation and passing data through screens
//

class Student {
  String studNo = '';
  String name = '';
  String surname = '';
  String email = '';
  String course = '';
  Student(
      {required this.studNo,
      required this.name,
      required this.surname,
      required this.email,
      required this.course});
}
